# NDice Indeed (Chrome Extension)

## What it does
- Runs automation on Dice job search pages.
- Manual run mode uses your currently open Dice search results page.
- Opens each listed job in a new tab, autofills supported application steps, and stops for final review before submission.
- Scheduled daily runs at 3 random times in the end user's local timezone.
- Scheduler never runs between 11:00 PM and 5:00 AM local time.
- Free plan supports up to 10 live applications per day.
- Starter supports up to 100 live applications per day for $9.99/month.
- Pro supports up to 450 live applications per day for $22.99/month.
- Unlimited supports unlimited live applications for $35.99/month, subject to fair-use protections.
- Saves detailed logs so you can review failures and improve rules.
- Supports dry-run mode for safe testing.
- Uses a review-first workflow for the final submit step.

## Files
- `manifest.json`: Extension config (MV3)
- `background.js`: Scheduler, orchestration, per-job tab pipeline, storage, logs
- `dice-content.js`: Search-page job collection + single-job autofill logic on dice.com
- `popup.html/js/css`: Controls for settings and manual run
- `logs.html/js/css`: Full log review and JSON export

## Subscription
- Free: 10 live submissions per local day, plus dry runs, local profile autofill, and logs.
- Starter monthly: 100 live submissions per local day for $9.99/month.
- Pro monthly: 450 live submissions per local day for $22.99/month.
- Unlimited monthly: unlimited live submissions for $35.99/month, subject to fair-use protections.
- Billing uses an external Stripe-backed service. Configure the checkout, portal, and validation URLs in `DEFAULT_SETTINGS.billing` in `background.js`.
- Subscription validation expects a JSON response with `plan`, `status`, `active`, `currentPeriodEnd`, optional `customerPortalUrl`, and optional `entitlements`.

## Install (Unpacked)
1. Open `chrome://extensions` in Chrome.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder: `dice-auto-apply-extension`.

## First-time setup
1. Open your Dice search results page with your desired filters.
2. Open extension popup.
3. Add profile fields (name, email, phone, etc.) for autofill.
4. Optionally enable `Dry run` first.
5. Click `Save`.
6. Click `Run now`.

## Log-driven improvement loop
1. Open `Open logs` from popup.
2. Review entries with `warn` and `error`.
3. Look for recurring statuses:
   - `manual_review_required`
   - `not_easy_apply`
   - `apply_button_missing`
   - `tab_flow_error`
4. Improve selectors or fill-rules in `dice-content.js`.
5. Re-test in dry-run mode.

## Notes
- Dice UI changes can break selectors; logging is included to spot these quickly.
- Some applications require uploads, custom questions, or explicit submit confirmation and may still need manual review.
- Use responsibly and in line with dice.com terms and your local requirements.
