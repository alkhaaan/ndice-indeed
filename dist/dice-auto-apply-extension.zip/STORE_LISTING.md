# Chrome Web Store Listing Draft

## Name
Dice Auto Apply Assistant

## Summary
Automates Dice Easy Apply workflows on a schedule and keeps detailed logs for review.

## Description
Dice Auto Apply Assistant helps streamline repetitive Dice application workflows.

It can:
- Run on a schedule at 9:00 AM ET, 1:00 PM ET, and 6:00 PM ET
- Open Dice job listings and attempt supported Easy Apply flows
- Keep detailed logs so you can review outcomes and improve settings over time
- Support dry-run mode for safe testing before live use
- Pause and resume the scheduler from the popup

Key features:
- Scheduled automation using Chrome alarms
- Per-job result tracking and run summaries
- Detailed logs for troubleshooting and iteration
- Profile autofill for common application fields
- Safer handling for manual-review cases such as uploads or unsupported forms

Important notes:
- This extension is designed for Dice pages only
- Website UI changes can affect automation behavior
- Some jobs may still require manual review
- Use responsibly and in accordance with Dice terms and your local requirements

## Category
Productivity

## Single Purpose
Automate supported Dice Easy Apply job application flows and log the results for review.

## Permissions Justification
- `storage`: saves settings, job history, and logs locally in Chrome
- `alarms`: runs the scheduled automation windows
- `tabs`: opens Dice job tabs and closes them after processing
- `scripting`: injects the content script when needed on Dice pages
- `https://*.dice.com/*`: limits automation access to Dice pages only

## Privacy Disclosure Draft
This extension stores configuration, logs, and job history locally in the user's browser storage. It interacts only with Dice pages needed to automate supported application flows. It does not declare any external server, analytics, or remote data transmission in this codebase.

## Store Assets Still Needed
- 128x128 extension icon PNG
- At least 1 screenshot, ideally 3 to 5
- Optional small promo tile for better listing presentation

## Suggested Screenshots
- Popup with schedule and profile settings
- Status area showing run summary and controls
- Logs page showing recent automation history
